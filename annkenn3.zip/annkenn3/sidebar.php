<?php
/*
Template Name: sidebar
*/
?>
<div class="category__gloup-box">
  <div class="category__box-a">
    <h2 class="category__title">カテゴリー</h2>
    <ul class="category__items">

    <?php
$categories = get_categories();

foreach ($categories as $category) {
  $args = array(
    'category_name' => $category->slug,
    'posts_per_page' => 5
  );
  $query = new WP_Query($args);

  if ($query->have_posts()) {
    while ($query->have_posts()) {
      $query->the_post(); ?>
      <li class="category__item">
        <a href="<?php the_permalink(); ?>">
          <?php $categories = get_the_category();
          foreach ($categories as $cat) {
            echo $cat->cat_name;
          } ?>
        </a>
      </li>
      <?php
    }
  }
  wp_reset_postdata();
}
?>
      
    </ul>
  </div>
  <div class="category__box-b">
        <h2 class="category__title">月別アーカイブ</h2>
        <ul class="category__items">
     <?php
       $args = array(
      'type' => 'monthly',
      // 'show_post_count' => true,
       );
      $archives = wp_get_archives($args);
       // アーカイブに日付を追加する  
      $archives = str_replace('</a>&nbsp;(', '</a> <span>', $archives);
      $archives = str_replace(')', '</span>', $archives);
      echo $archives;
      ?>
    </ul>
  </div>
</div>

