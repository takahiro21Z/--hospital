<?php
  function my_setup(){
    add_theme_support('post-thumbnails'); // アイキャッチ画像を有効化
    add_theme_support('automatic-feed-links'); // 投稿とコメントのRSSフィードのリンクを有効化
    add_theme_support('title-tag'); // titleタグ自動生成
    add_theme_support('html5', array( // HTML5による出力
      'search-form',
      'comment-form',
      'comment-list',
      'gallery',
      'caption',
    ));
  }
  add_action('after_setup_theme', 'my_setup');
  add_theme_support( 'post-thumbnails',array('page') );





// 投稿のアーカイブページを作成する
function post_has_archive($args, $post_type)
{
    if ('post' == $post_type) {
        $args['rewrite'] = true; // リライトを有効にする
        $args['has_archive'] = 'news'; // 任意のスラッグ名
        $args["label"] = "投稿" ;
    }
    return $args;
}
add_filter('register_post_type_args','post_has_archive', 10, 2);

// Contact Form 7で自動挿入されるPタグ、brタグを削除
add_filter('wpcf7_autop_or_not', 'wpcf7_autop_return_false');
function wpcf7_autop_return_false() {
  return false;
} 


// アイキャッチ画像
function custom_setup(){
    add_theme_support('post-thumbnails');
}
add_action('after_setup_theme','custom_setup');
add_filter('register_post_type_args', 'post_has_archive', 10, 2);



function add_stylesheet() {
  wp_enqueue_style(
      'main', // mainという名前を設定
      get_template_directory_uri().'/css/style.css', // パス
      array(), // style.cssより先に読み込むCSSは無いので配列は空
  );
}
add_action('wp_enqueue_scripts', 'add_stylesheet');
  // wp_enqueue_scriptsフックにadd_stylesheet関数を登録

  
  add_filter('register_post_type_args', 'post_has_archive', 10, 2);
  // アイキャッチ画像を有効にする。
add_theme_support('post-thumbnails');
add_image_size( 'thumbnail', 300, 200, true );
set_post_thumbnail_size( 300, 200, true );

register_post_type(
    'event',
    // 'supports'に'thumbnail'を追記
    array('supports' => array('title','editor','thumbnail'))
);


