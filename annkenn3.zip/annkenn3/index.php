<?php get_header(); ?>
  <!-- main開始 -->
  
<main>
  <!-- MV開始 -->
 <section class="mv">
  <div class="mv__inner heder-inner">
       <h2 class="mv__text">
          <img src="<?php echo get_template_directory_uri();?>/./img/top/mv_text_pc.svg" alt="">
       </h2> 
       <div class="main_imgbox">
         <div class="swiper-container">
          <div class="swiper-wrapper">
              <div class="swiper-slide">
                  <div class="slide-item">
                    <picture>
                      <source srcset="<?php echo get_template_directory_uri();?>/./img/top/top_mv_1_sp.jpg" media="(max-width:768px)">  <!-- スマホ画像 -->
                      <img class="slide-img" src="<?php echo get_template_directory_uri();?>/./img/top/top_mv_1.jpg" alt="診察の様子の画像">
                    </picture>
                 </div>
             </div>
              <div class="swiper-slide">
                   <div class="slide-item">
                    <picture>
                      <source srcset="<?php echo get_template_directory_uri();?>/./img/top/top_mv_2_sp.jpg" media="(max-width:768px)">  <!-- スマホ画像 -->
                      <img class="slide-img" src="<?php echo get_template_directory_uri();?>/./img/top/top_mv_2.jpg" alt="治療の様子">
                    </picture>
              </div>
              </div>
              <div class="swiper-slide">
                   <div class="slide-item">
                    <picture>
                      <source srcset="<?php echo get_template_directory_uri();?>/./img/top/top_mv_3_sp.jpg" media="(max-width:768px)">  <!-- スマホ画像 -->
                      <img class="slide-img" src="<?php echo get_template_directory_uri();?>/./img/top/top_mv_3.jpg" alt="外観">
                    </picture>
             </div>
         </div>
         </div>
      </div>
    </div>
  </div> 
 </section>
 <!-- MV終了 -->
 <!-- NEWS開始 -->
 <section class="news">
  <div class="news__inner inner">
        <h2 class="section-title">
          <span class="section-title__ja">お知らせ</span>
          <span class="section-title__en">News</span>
        </h2>
        <div class="top-news__info">
          <a href="" class="top-news-info">
            <div class="top-news-info__wrap">
              <div class="top-news-info__box">
                <time datetime="2022-03-31" class="top-news-info__date">2022.03.31</time>
                <span class="top-news-info__category" style="color: #FFB576; border-color: #FFB576;">
                  営業時間について</span>
              </div>
              <span class="top-news-info__title">
                コロナウイルス拡大に伴う営業時間短縮のお知らせ
                コロナウイルス拡大に伴う営業時間短縮のお知らせ
              </span>
            </div>
            <span class="top-news-info__arrow"></span>
          </a>
          <a href="<?php echo home_url(); ?>/news" class="top-news-info">
            <div class="top-news-info__wrap">
              <div class="top-news-info__box">
                <time datetime="2022-03-31" class="top-news-info__date">2022.03.31</time>
                <span class="top-news-info__category" style="color: #FF7676; border-color: #FF7676;">
                  営業時間について</span>
              </div>
              <span class="top-news-info__title u-desktop">
                コロナウイルス拡大に伴う営業時間短縮のお知らせ
              </span>
              <span class="top-news-info__title u-mobile">
                コロナウイルス拡大に伴う営業時間短縮のお知らせコロナウイルス
              </span>
            </div>
            <span class="top-news-info__arrow"></span>
          </a>
          <a href="" class="top-news-info">
            <div class="top-news-info__wrap">
              <div class="top-news-info__box">
                <time datetime="2022-03-31" class="top-news-info__date">2022.03.31</time>
                <span class="top-news-info__category" style="color: #76ABFF; border-color: #76ABFF;">
                  営業時間について</span>
              </div>
              <span class="top-news-info__title u-desktop">
                コロナウイルス拡大に伴う営業時間短縮のお知らせ
              </span>
              <span class="top-news-info__title u-mobile">
                コロナウイルス拡大に伴う営業時間短縮のお知らせコロナウイルス拡大に伴う営業時間短縮のお知らせ
              </span>
            </div>
            <span class="top-news-info__arrow"></span>
          </a>
        </div>
      <div class="top-news__btn news-btn">
        <a href="news.html" class="btn-main">もっと見る</a>
      </div>
    </div>
</section>
<!-- お知らせ終了 -->

<!-- クリニックのご紹介 -->
<section class="about about-top">
  <div class="about__inner inner">
  <div class="about-flex about-flex-reverse">
    <div class="flex__img-wrap">
      <div class="flex__img flex__img-reverse">
        <img src="<?php echo get_template_directory_uri();?>/./img/top/top_about_1.jpg" alt="">
      </div>
     <div class="flex__img flex__img-row">
      <img src="<?php echo get_template_directory_uri();?>/./img/top/top_about_2.jpg" alt="">
     </div>
    <div class="flex__body">
      <h2 class="section-title">
        <span class="section-title__ja">クリニックのご紹介</span>
        <span class="section-title__en">About</span>
      </h2>
      <p class="about-catch-copy catch-copy">安心して相談できるかかりつけ医</p>
      <p class="about-catch-copy__text">
        地域の皆様の第一の相談相手になりたい <br>頭のことなら”渡邉脳神経外科クリニック” <br>
      そんなニーズにお応えできるクリニックを<br class="u-mobile">目指しています。</p>
      <div class="top-about__btn about-btn u-desktop">
        <a href="about.html" class="btn-main btn-pc">クリニックのご紹介</a>
      </div>
      <div class="top-about__btn about-btn u-mobile">
        <a href="about.html" class="btn-main">もっと見る</a>
      </div>
    </div>
    </div>
  </div>
</div>
</section>

<!-- Treatment -->

<section class="treatment treatment-top">
  <div class="treatment__inner inner">  
   <div class="treatment-flex treatment-flex-reverse">
    <div class="treatment__img-wrap">
      <div class="treatment__img treatment__img-reverse">
        <img src="<?php echo get_template_directory_uri();?>/./img/top/top_treatment_1.jpg" alt="">
      </div>
     <div class="treatment__img treatment__img-row">
      <img src="<?php echo get_template_directory_uri();?>/./img/top/top_treatment_2.jpg" alt="">
     </div>
    <div class="treatment__body">
      <h2 class="section-title">
        <span class="section-title__ja">診療科目</span>
        <span class="section-title__en">Treatment</span>
      </h2>
      <p class="treatment-catch-copy catch-copy">早期発見・早期治療が<br class="u-mobile">大事な脳の病気。</p>
      <div class="treatment-text__box">
         <p class="treatment-catch-copy__text treatment-text-a">頭の専門医として、脳卒中や認知症だけではなく、<br class="u-mobile">頭痛やめまい、しびれなどの</p>
         <p class="treatment-catch-copy__text treatment-text-c">日常的な症状まで幅広く治療を行っております。</p>
         <p class="treatment-catch-copy__text treatment-text-d">どんなに小さな悩みでもお気軽にご相談ください。</p>
      </div>
      <div class="top-treatment__btn treatment-btn u-desktop">
        <a href="treatment.html" class="btn-main btn-pc">クリニックのご紹介</a>
      </div>
      <div class="top-treatment__btn treatment-btn u-mobile">
        <a href="treatment.html" class="btn-main">もっと見る</a>
      </div>
    </div>
    </div>
  </div>
</div>
</section>

<!-- お問い合わせ -->
<section class="contact cotact-top">
  <div class="contact__img"></div>
  <div class="contact__wrapper">
    <div class="contact__title">
   <h2 class="section-title contact-title">
      <span class="section-title__ja">お問い合わせ</span>
      <span class="section-title__en">Contact</span>
    </h2>
    <p class="contact-catch-copy__text">当クリニックは地域の皆様の第一の相談相手を <br class="u-mobile">
      目指しております。 
      <br>何でもお気軽にお問合せください。</p>
    <div class="top-contct__btn contact-btn u-desktop">
      <a href="contact.html" class="btn-main btn-pc">クリニックのご紹介</a>
    </div>
    <div class="top-contact__btn contact-btn u-mobile">
      <a href="contact.html" class="btn-main">お問い合わせへ</a>
    </div>
  </div>
</div>
 
</section>

<!-- アクセス -->
<section class="access access-top">
  <div class="access__inner inner">
  <h2 class="section-title contact-title">
    <span class="section-title__ja">アクセス</span>
    <span class="section-title__en">Access</span>
  </h2>
  <div class="access__map">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3117.09382305491!2d139.74388822386393!3d35.65903105083354!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x60188bbd9009ec09%3A0x481a93f0d2a409dd!2z5p2x5Lqs44K_44Ov44O8!5e0!3m2!1sja!2sjp!4v1678445780987!5m2!1sja!2sjp" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
  </div>
  <p class="access__text">病院の敷地内に6台の駐車スペースを <br class="u-mobile">ご用意しております。 
    <br>※駐車場内での事故等のトラブルについては一切責任を負いかねます。
    あらかじめご了承ください。</p>

<table class="biz-hour">
  <tbody>
    <tr>
      <th class="tabel-time">診療時間</th>
      <th>月</th>
      <th>火</th>
      <th>水</th>
      <th>木</th>
      <th>金</th>
      <th class="sat">土</th>
      <th class="sun">日</th>
    </tr>
    <tr>
      <th class="tabel-time">10:00-12:30</th>
      <td>●</td><!-- 月 -->
      <td>●</td><!-- 火 -->
      <td>●</td><!-- 水 -->
      <td>●</td><!-- 木 -->
      <td>●</td><!-- 金 -->
      <td>●</td><!-- 土 -->
      <td>×</td><!-- 日 -->
    </tr>
    <tr>
      <th class="tabel-time">14:00-17:00</th>
      <td>●</td><!-- 月 -->
      <td>●</td><!-- 火 -->
      <td>●</td><!-- 水 -->
      <td>×</td><!-- 木 -->
      <td>●</td><!-- 金 -->
      <td>×</td><!-- 土 -->
      <td>×</td><!-- 日 -->
    </tr>
  </tbody>
</table>
</div>
</section>
   </main>
<!-- フッター -->
<?php get_footer(); ?>
