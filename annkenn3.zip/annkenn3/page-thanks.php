<?php
/*
Template Name: page-thanks
*/
?>

<?php get_header(); ?>

<main>
 <!-- about-mv -->
<section class="about-mv">
  <div class="about-mv-wrapper">
    <div class="about-mv__contet contact-page__img">
      <div class="about-mv__img">
        <img src="<?php echo get_template_directory_uri();?>/./img/contact/contact_mv.jpg" alt="治療中の画像">
      </div>
      <div class="about-mv__title">
        <h2>Contact</h2><span>お問い合わせ</span>
      </div>
    </div>
  </div>
  <div class="about-mv__inner inner">
    <div class="btn__wrapper">
    <div class="home__btn">
      <a href="/index.php?page_id=11">HOME</a>
    </div>
    <div class="home__btn">
      <a href="index.php?page_id=114">お問い合わせ</a>
    </div>
    <div class="about__btn">
      <a href="">お問い合わせ完了</a>
    </div>
   </div>
  </div>
</section>

<section class="sent sent-top">
  <div class="sent__inner inner">
  <h2 class="section-title sent__title">
    <span class="section-title__ja treatment-title-ja"><?php the_title(); ?></span>
  </h2>
  <div class="sent__text">
    <p>この度はお問い合わせいただき、有難うございました。<br></p> 
    <p>3営業日以内にご返信させていただきますので、しばらくお待ちくださいませ。</p>
  </div>
  <div class="sent__btn"><a href="/index.php?page_id=11">ホームに戻る</a>
</div>
</div>
</section>

   </main>

   <?php get_footer(); ?>