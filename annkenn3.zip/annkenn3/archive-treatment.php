<?php
/*
Template Name: arcive-treatment
*/
?>


<?php get_header(); ?>

<main>
 <!-- treatment-mv -->
<section class="treartment treartment-page-top">
  <div class="treartment-mv-wrapper">
    <div class="treartment-mv__contet">
      <div class="treartment-mv__img">
        <img src="<?php echo get_template_directory_uri();?>/./img/treatment/treatment_mv.jpg" alt="治療中の画像">
      </div>
      <div class="treartment-mv__title">
        <h2>Treatoment</h2><span>診療科目</span>
      </div>
    </div>
  </div>
  <div class="treartment-mv__inner inner">
  <div class="breadcrumbs" typeof="BreadcrumbList" vocab="https://schema.org/">
    <?php if(function_exists('bcn_display'))
    {
        bcn_display();
    }?>
</div>
  </div>
</section>

<!-- treatment-body -->
<section class="treatment treatment-date">
  <div class="treatment-date__inner inner">
    <div class="treatment__btn-wrapper">
      <div class="treatment__btn treatment__btn-a">
        <a href="#pain" class="treatment-btn-a">身体の痛み</a>
      </div>
      <div class="treatment__btn treatment__btn-b">
        <a href="#pain-malaise" class="treatment-btn-a">身体機能の不調</a>
      </div>
      <div class="treatment__btn treatment__btn-c">
        <a href="#pain-medical" class="treatment-btn-a">健診</a>
      </div>
    </div>
<h2 id="pain" class="section-title treatment-title treatment__cards-title">
  <span class="section-title__ja treatment-title-ja">身体の痛み</span>
</h2>
<div class="treatment-message-box treatment-cards__text">
  <p>ちょっとした痛みからやってくる病気も少なからず存在します。</p>
  <p> 少しでも異変を感じたら早期に受診しましょう。</p>
</div>
<div class="treatment-crads">
  <div class="treatment-card-item">
    <div class="treatment-card-img"><a href="/index.php?page_id=366">
      <img src="<?php echo get_template_directory_uri();?>/./img/treatment/treatment_eyecatch_1.jpg" alt="頭痛"></a>
    </div>
    <p class="treatment-card__text">頭痛</p>
  </div>
  <div class="treatment-card-item">
    <div class="treatment-card-img"><a href="/index.php?page_id=378">
      <img src="<?php echo get_template_directory_uri();?>/./img/treatment/treatment_eyecatch_2.jpg" alt="首・肩の痛み"></a>
    </div>
    <p class="treatment-card__text">首・肩の痛み</p>
  </div>
  <div class="treatment-card-item">
    <div class="treatment-card-img"><a href="/index.php?page_id=383">
      <img src="<?php echo get_template_directory_uri();?>/./img/treatment/treatment_eyecatch_3.jpg" alt="腰・臀部・足の痛み"></a>
    </div>
    <p class="treatment-card__text">腰・臀部・足の痛み</p>
  </div>
</div>
<h2 id="pain-malaise" class="section-title treatment-title treatment__cards-title">
  <span class="section-title__ja treatment-title-ja">身体機能の不調</span>
</h2>
<div class="treatment-message-box treatment-cards__text">
  <p>歩行障害や呂律が回らないなど、脳の病気を疑う要注意症状です。</p>
  <p>一刻も早く頭部CT/MRIなどの精査を行い、速やかに原因を特定、治療を開始する必要があります。</p>
</div>
<div class="treatment-crads">
  <div class="treatment-card-item">
    <div class="treatment-card-img"><a href="/index.php?page_id=386">
      <img src="<?php echo get_template_directory_uri();?>/./img/treatment/treatment_eyecatch_4.jpg" alt="歩行障害"></a>
    </div>
    <p class="treatment-card__text">歩行障害</p>
  </div>
  <div class="treatment-card-item">
    <div class="treatment-card-img"><a href="/index.php?page_id=389">
      <img src="<?php echo get_template_directory_uri();?>/./img/treatment/treatment_eyecatch_5.jpg" alt="めまい・ふらつき"></a>
    </div>
    <p class="treatment-card__text">めまい・ふらつき</p>
  </div>
  <div class="treatment-card-item">
    <div class="treatment-card-img"><a href="/index.php?page_id=392">
      <img src="<?php echo get_template_directory_uri();?>/./img/treatment/treatment_eyecatch_6.jpg" alt="呂律が回らない"></a>
    </div>
    <p class="treatment-card__text">呂律が回らない</p>
  </div>
</div>
<h2 id="pain-medical" class="section-title treatment-title treatment__cards-title">
  <span class="section-title__ja treatment-title-ja">健診</span>
</h2>
<div class="treatment-message-box treatment-cards__text">
  <p>脳卒中は予防が第一です。早期発見・早期治療で人生まだまだ楽しみたい！</p>
  <p>脳の状態を知ることのできる大変貴重な機会です。一度受診してみませんか？</p>
</div>
<div class="treatment-crads">
  <div class="treatment-card-item">
    <div class="treatment-card-img"><a href="/index.php?page_id=395">
      <img src="<?php echo get_template_directory_uri();?>/./img/treatment/treatment_eyecatch_7.jpg" alt="脳卒中予防"></a>
    </div>
    <p class="treatment-card__text">脳卒中予防</p>
  </div>
  <div class="treatment-card-item">
    <div class="treatment-card-img"><a href="/index.php?page_id=399">
      <img src="<?php echo get_template_directory_uri();?>/./img/treatment/treatment_eyecatch_8.jpg" alt="脳ドック"></a>
    </div>
    <p class="treatment-card__text">脳ドック</p>
  </div>
</div>

 </div>
</section>

   </main>


<?php get_footer(); ?>