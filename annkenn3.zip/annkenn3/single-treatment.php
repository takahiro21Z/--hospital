<?php
/*
Template Name: single-treatment
*/
?>

<?php get_header(); ?>

<main>
 <!-- treatment-mv -->
<section class="treartment treartment-page-top">
  <div class="treartment-mv-wrapper">
    <div class="treartment-mv__contet">
      <div class="treartment-mv__img">
      <img src="<?php echo get_template_directory_uri();?>/./img/treatment/treatment_mv.jpg" alt="治療中の画像">
      </div>
      <div class="treartment-mv__title">
        <h2>Treatoment</h2><span>診療科目</span>
      </div>
    </div>
  </div>
  <div class="treartment-mv__inner inner">
    <div class="btn__wrapper">
    <div class="home__btn">
      <a href="index.php?page_id=11">HOME</a>
    </div>
    <div class="treartment__btn home__btn">
      <a href="index.php?page_id=108">診療科目</a>
    </div>
    <div class="treartment__btn">
      <a href=""><?php echo get_the_title (); ?></a>
    </div>
   </div>
  </div>
</section>

<section class="headache headache-top">
  <div class="headache__inner inner">
  <div class="headache__wrapper">
  <?php
  $thumbnail_id = get_post_thumbnail_id();
  if ($thumbnail_id):
    $img_url = wp_get_attachment_image_src($thumbnail_id, 'full')[0];
  ?>
  <img src="<?php echo $img_url; ?>" alt="アイキャッチ画像">
  <?php endif; ?>
</div>
<div class="text-wrapper">
  <h2 class="headache__title"><?php echo get_the_title(); ?></h2>
  <div class="headache__text-box">
    <p class="headache-text"><?php echo get_the_content(); ?></p>
  </div>
</div>

  <div class="headache-btn">
    <a href="/index.php?page_id=108" class="treatment-btn-a">診療科目一覧へ</a>
  </div>

</div>

</section>

</main>

<?php get_footer(); ?>