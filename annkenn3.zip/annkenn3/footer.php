<footer class="footer footer-top">
    <div class="footer__inner inner">
      <div class="footer__wrapper">
        <nav class="footer__nav">
          <ul class="footer__nav-items">
            <li class="footer__nav-item">
              <a href="/index.php?page_id=11">ホーム</a>
            </li>
            <li class="footer__nav-item">
              <a href="/index.php?page_id=102">クリニックについて</a>
            </li>
            <li class="footer__nav-item">
              <a href="/index.php?page_id=195">お知らせ</a>
            </li>
            <li class="footer__nav-item">
              <a href="index.php?page_id=108">診療案内</a>
            </li>
            <li class="footer__nav-item">
              <a href="index.php?page_id=114">お問い合わせ</a>
            </li>
          </ul>
          <div class="footer-line"></div>
        </nav>
        <div class="footer__logo">
          <img src="<?php echo get_template_directory_uri();?>/./img/common/footer_logo.png" alt="">
        </div>
      </div>
      <div class="footer__text-box">
        <div class="footer__text-gloup">
        <p class="foter-text">福岡県福岡市中央区渡邉123</p>
        <p class="footer-tel">Tel. 093-0000-0000</p>
      </div>
    </div>
  </div>
    <div class="footer-bottom">
      <p>©︎2022 Watanabe neuro-spone clinic</p>
    </div>
   </footer>
   <?php wp_footer(); ?>
  </body>
</html>




