<?php
/*
Template Name: 404error
*/
?>


<?php get_header(); ?>

<div class="about-mv-wrapper">
    <div class="about-mv__contet contact-page__img">
      <div class="about-mv__img">
        <img src="<?php echo get_template_directory_uri();?>/./img/contact/contact_mv.jpg" alt="治療中の画像">
      </div>
      <div class="about-mv__title">
        <h2>404</h2><span>Not Found</span>
      </div>
    </div>
  </div>

  <div class="contact-page__inner inner">
    <div class="contact-page__wrapper">
  <h2 class="section-title contact-page__title">
      <span class="section-title__ja">404エラー</span>
    </h2>
    <p class="contact-page__text">
      お探しのページは見つかりませんでした。
    </p>
    <div class="sent__btn"><a href="/index.php?page_id=11">ホームに戻る</a>
</div>
    </div>
  </div>

<?php get_footer(); ?>