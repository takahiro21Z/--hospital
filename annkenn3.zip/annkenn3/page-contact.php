<?php
/*
Template Name: page-contact
*/
?>
<?php get_header(); ?>


<main>
 <!-- about-mv -->
<section class="about-mv">
  <div class="about-mv-wrapper">
    <div class="about-mv__contet contact-page__img">
      <div class="about-mv__img">
        <img src="<?php echo get_template_directory_uri();?>/./img/contact/contact_mv.jpg" alt="治療中の画像">
      </div>
      <div class="about-mv__title">
        <h2>Contact</h2><span>お問い合わせ</span>
      </div>
    </div>
  </div>
  <div class="about-mv__inner inner">
  <div class="breadcrumbs" typeof="BreadcrumbList" vocab="https://schema.org/">
    <?php if(function_exists('bcn_display'))
    {
        bcn_display();
    }?>
</div>
  </div>
</section>

<section class="contact-page">
  <div class="contact-page__inner inner">
    <div class="contact-page__wrapper">
  <h2 class="section-title contact-page__title">
      <span class="section-title__ja">お問い合わせフォーム</span>
    </h2>
    <p class="contact-page__text">
      ご質問、ご要望、ご相談は下記フォームを<br class="u-mobile"> ご利用ください。
      <br> ※体調に不安がある方は、直接医師の診察をお勧めします。</p>
    </div>
  </div>




<div class="contact__form">

<div class="form-label-area">

  <?php the_content(); ?>

</div>
</div>

</section>

   </main>



<?php get_footer(); ?>