<?php
/*
Template Name: date
*/
?>
<?php get_header(); ?>
<main>
<div class="treartment-mv__contet news-mv__contet">
           <div class="news-mv__img">
              <img src="<?php echo get_template_directory_uri();?>/./img/news/news_mv.jpg" alt="治療中の画像">
          </div>
          <div class="treartment-mv__title">
              <h2>News</h2><span>お知らせ</span>
          </div>
    </div>


 <!-- treatment-mv -->
 <div class="news-link__inner inner">
 <div class="breadcrumbs" typeof="BreadcrumbList" vocab="https://schema.org/">
    <?php if(function_exists('bcn_display'))
    {
        bcn_display();
    }?>
          
</div>

      <!-- 記事 -->
      <div class="news__container">
      <ul class="news__wrapper">  
        <!-- ループ開始 -->
       <?php if (have_posts()): ?>
       <?php while (have_posts()) : the_post(); ?>
        <a href="<?php the_permalink(); ?>" class="news-link__wrapper">
           <li class="news-item">
           <div class="news-link__meta">
                 <?php $this_terms = get_the_terms( get_the_ID(), 'category' );
                  if ( $this_terms ) {
                  $this_term_color = get_field( 'color', 'category_' . $this_terms[0]->term_id );
                  $this_term_name = $this_terms[0]->name;
                   echo '<span class="entry-label" style="color:' . $this_term_color . ';">' . $this_term_name . '</span>';
                  }
                  ?>
                <div class="news-link__text">
                    <?php echo get_the_title (); ?>
                </div>
                <time datetime="2022-03-31">
                   <?php echo get_the_date("Y.m.d"); ?>
                </time>
             </div>
             <div class="news-link__img">
               <img src="<?php echo get_the_post_thumbnail_url() ?>" alt="">
             </div>
          </li>   <!-- news-link__wrapper -->
         </a>
       <?php endwhile; ?><?php endif; ?>
               <!-- ループ終わり -->
     </ul>   <!-- news__wrapper -->
      <?php get_sidebar(); ?>
   </div>   <!-- news__container -->

  </div>
   </main>

  

<!--pagevavi-->

<?php
$paged = get_query_var('paged') ? get_query_var('paged') : 1;
$args = array(
    'post_type' => 'post',
    'posts_per_page' => 5,
    'paged' => $paged
);

$my_query = new WP_Query( $args );

if ( $my_query->have_posts() ) :
    while ( $my_query->have_posts() ) :
        $my_query->the_post();
        // ループ内で記事情報を表示するためのコードを記述
    endwhile;
    wp_reset_postdata();
endif;

// ページネーションの出力
if ( function_exists( 'wp_pagenavi' ) ) {
    wp_pagenavi( array( 'query' => $my_query ) );
}
?>

<!--pagevavi-->

<?php get_footer(); ?>



