<?php
/*
Template Name: page-about
*/
?>


<?php get_header(); ?>


<main>
 <!-- about-mv -->
<section class="about-mv">
  <div class="about-mv-wrapper">
    <div class="about-mv__contet">
      <div class="about-mv__img">
        <img src="<?php echo get_template_directory_uri();?>/./img/about/about_hospital_6.jpg" alt="治療中の画像">
      </div>
      <div class="about-mv__title">
        <h2>About</h2><span>クリニックのご紹介</span>
      </div>
    </div>
  </div>
  <div class="about-mv__inner inner">
  <div class="breadcrumbs" typeof="BreadcrumbList" vocab="https://schema.org/">
    <?php if(function_exists('bcn_display'))
    {
        bcn_display();
    }?>
</div>
 
  </div>
</section>

<!-- 院内紹介 -->

<section class="director director-top">
  <div class="director__inner inner"> 
     <h2 class="director__title">院長紹介</h2>
    <div class="director__wrapper">
      <div class="director__img">
        <img src="<?php echo get_template_directory_uri();?>/./img/about/about_head-doctor.jpg" alt="院長の画像" srcset="">
      </div> 
      <div class="director__text-box">
        <p>院長の渡邊和則と申します。 </p>
        <p class="director__text-a">平成10年に医師免許を取得し、その後脳神経外科専門医を取得。</p> 
        <p class="director__text-b">大学病院や総合病院での経験を経て、平成20年に日本脳卒中学会脳卒中専門医を取得。
          平成28年、福岡市に「渡邉脳神経外科クリニック」を開院させていただくことになりました。</p> 
        <p class="director__catct-coppy">“あなたの第一の相談相手”</p> 
          <p class="director__text-d">当クリニックではつらい症状から些細な症状まで気軽に受診できる、
          地域に密着したクリニックを目指しております。 </p>
          <p class="director__text-e">ちょっとした軽い症状を放置し、取り返しのつかない事態となることも少なくありません。
          どんなに些細な症状や心配事でも構いませんので、どうぞお気軽に受診ください。</p>
          <div class="director__sign">
            <div class="director__sign-text">渡邉脳神経外科クリニック院長
              <span class="director__sign-img">
                <img src="<?php echo get_template_directory_uri();?>/./img/about/about_head-doctor_sign.png" alt="院長のサイン画像">
              </span>
            </div>
          </div>
        </div>  
    </div>
  </div>
</section>

<section class="introduction introduction-top"> 
<div class="introduction__inner inner">
  <h2 class="introduction__title">院内紹介</h2>
  <div class="introduction__text-wrapper">
  <div class="introduction__text-box">
    <p class="introduction__text-a">ご来院の皆さまがリラックスして診察を受けていただけるよう、木目を基調とした清潔感ある<br class="u-desktop">落ち着いた空間造りを目指しています。</p> 
    <p class="introduction__text-b">最新の装置を導入し、異常の早期発見、早期対応ができるように努めています。</p>
    <p class="introduction__text-c">他の医療機関とも連携体制を構築し、患者様に適切な医療を提供いたします。</p>
 </div>
</div>
 <div class="introduction__img-box">
  <div class="introduction__img">
    <img src="<?php echo get_template_directory_uri();?>/./img/about/about_hospital_1.jpg" alt="院内画像1">
  </div>
  <div class="introduction__img">
    <img src="<?php echo get_template_directory_uri();?>/./img/about/about_hospital_2.jpg" alt="院内の廊下">
  </div>
  <div class="introduction__img"> 
    <img src="<?php echo get_template_directory_uri();?>/./img/about/about_hospital_3.jpg" alt="治療中の画像">
  </div>
  <div class="introduction__img"> 
    <img src="<?php echo get_template_directory_uri();?>/./img/about/about_hospital_4.jpg" alt="治療中の画像">
  </div>
  <div class="introduction__img"> 
    <img src="<?php echo get_template_directory_uri();?>/./img/about/about_hospital_5.jpg" alt="治療中の画像">
  </div>
  <div class="introduction__img"> 
    <img src="<?php echo get_template_directory_uri();?>/./img/about/about_hospital_6.jpg" alt="治療中の画像">
  </div>
 </div>
</div> 
</section>
   </main>

<?php get_footer(); ?>