<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1.0" />
  <meta name="format-detection" content="telephone=no" />
  <!-- meta情報 -->
  <title>タイトル</title>
 
 
  <meta name="description" content="" />
  <meta name="keywords" content="" />
  <!-- ogp -->
  <meta property="og:title" content="" />
  <meta property="og:type" content="" />
  <meta property="og:url" content="" />
  <meta property="og:image" content="" />
  <meta property="og:site_name" content="" />
  <meta property="og:description" content="" />
  <!-- ファビコン -->
  <link rel="shortcut icon" href="#" type="image/x-icon" />
  <!-- css -->
  <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/./css/style.css">
  <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css"/>
    <!-- JavaScript -->
  <script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script defer src="<?php echo get_template_directory_uri();?>/./js/script.js"></script>
  <?php wp_enqueue_script("jquery"); ?>
  <?php wp_head(); ?>
</head>
<body>
  <!-- ヘッダー開始 -->
  <header class="header header_contents">
    <div class="header__inner header-inner">
      <h1 class="header__logo">
        <a href=""><img src="<?php echo get_template_directory_uri();?>/./img/common/header_logo.png" alt="病院のロゴ"></a>
      </h1>
      <button class="header__hamburger hamburger openbtn1 js-hamburger">
        <span></span>
        <span></span>
        <span></span>
      </button>
      <nav class="header__nav header-nav g-nav js-drawer">
        <ul class="header-nav__items">
          <li class="header-nav__item">
            <a href="/index.php?page_id=102">クリニックについて</a>
            <div class="header-nav__img u-mobile">
            <img src="<?php echo get_template_directory_uri();?>/./img/common/Line.png" alt="青いライン">
          </div>
          </li>
          <li class="header-nav__item item-list">
            <a href="/index.php?page_id=195">お知らせ</a>
            <div class="header-nav__img u-mobile">
              <img src="<?php echo get_template_directory_uri();?>/./img/common/Line.png" alt="青いライン">
            </div>
          </li>
          <li class="header-nav__item item-list">
            <a href="index.php?page_id=108">診療案内</a>
            <div class="header-nav__img u-mobile">
              <img src="<?php echo get_template_directory_uri();?>/./img/common/Line.png" alt="青いライン">
            </div>
          </li>
          <li class="header-nav__item item-list">
            <a href="index.php?page_id=114">お問い合わせ</a>
            <div class="header-nav__img u-mobile">
              <img src="<?php echo get_template_directory_uri();?>/./img/common/Line.png" alt="青いライン">
            </div>
          </li>
        </ul>
      </nav>
    </div>
    <div class="circle-bg"></div>
  </header>
  <!-- ヘッダー終了 -->
	
	<?php if( !(is_home() || is_front_page() )): ?>
<div class="breadcrumb-area">
<?php
if ( function_exists( 'bcn_display' ) ) {
bcn_display();
}
?>
</div>
<?php endif; ?>
