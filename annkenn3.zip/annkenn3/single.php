<?php
/*
Template Name: news-list
*/
?>

<?php get_header(); ?>


<main>
 <!-- treatment-mv -->
    <section class="treartment treartment-page-top">
    <div class="treartment-mv__contet news-mv__contet">
       <div class="news-mv__img">
           <img src="<?php echo get_template_directory_uri();?>/./img/news/news_mv.jpg" alt="治療中の画像">
       </div>
       <div class="treartment-mv__title">
           <h2>News</h2><span>お知らせ</span>
       </div>
      </div>
      <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="https://schema.org/">
    <?php if(function_exists('bcn_display'))
    {
        bcn_display();
    }?>
</div>
</section>

<section class="news-page">
  <div class="news-page__inner inner">
      <div class="news-page__wrapper">
          <div class="news-page__box">
               <div class="news-page__img">
                     <img src="<?php echo get_template_directory_uri();?>/./img/news/news_eyecatch.jpg" alt="">
               </div>
               <div class="news-page__items">
                      <?php $this_terms = get_the_terms( get_the_ID(), 'category' );
                       if ( $this_terms ) {
                       $this_term_color = get_field( 'color', 'category_' . $this_terms[0]->term_id );
                       $this_term_name = $this_terms[0]->name;
                       echo '<span class="entry-label" style="color:' . $this_term_color . ';">' . $this_term_name . '</span>';
                      }
                       ?>
                  <div>
                      <time datetime="2022-03-31">
                          <?php echo get_the_date("Y.m.d"); ?>
                      </time>
                  </div>
                  </div>
                  <div class="news-page__title">
                     <?php echo get_the_title(); ?>
                    
                 </div>
                 <p class="news-page__text">
                      <?php echo get_the_content(); ?>
                  </p>  
  
         </div>     <!-- news-page__box -->
        
         <div class="navigation-box  clearfix-sp">
                        <p class="navileft navigation-item">
                             <?php previous_post_link('< %link', '前の記事へ'); ?>
                        </p>
                      
                        <p class="naviright navigation-item">
                             <?php next_post_link('%link >', '次の記事へ'); ?>
                        </p>
                       
                 </div>
                 <p class="news-page__btn news-page__sp">
                             <a href="/index.php?page_id=195" class="">お知らせ一覧へ</a>
                        </p> 
             
         <?php get_sidebar(); ?>
                 
         
     </div><!-- news-page__wrapper -->      
     <div class="navigation-box clearfix clearfix-pc">
                        <p class="navileft navigation-item">
                             <?php previous_post_link('< %link', '前の記事へ'); ?>
                        </p>
                        <p class="news-page__btn">
                             <a href="/index.php?page_id=195" class="">お知らせ一覧へ</a>
                        </p> 
                        <p class="naviright navigation-item">
                             <?php next_post_link('%link >', '次の記事へ'); ?>
                        </p>
                 </div>

 
</div>  <!-- news-page__inner inner -->
</section>
</main>

<?php get_footer(); ?>
             
    
